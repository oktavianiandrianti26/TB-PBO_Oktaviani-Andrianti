public interface Showroom { //class interface
    public void idMobil();  //menampung nilai
    public void merkMobil();
    public void tipeMobil();
    public void Harga();
    public void statusMobil();
    public void pelanggan();
    public void totalharga();
}
